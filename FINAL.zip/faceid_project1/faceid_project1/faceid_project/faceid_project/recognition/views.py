from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .forms import UploadImageForm
from .models import UploadedImage

# Home page
def index(request):
    return render(request, 'recognition/index.html')

# Login view
def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('index')
        else:
            messages.error(request, "Invalid credentials")
    return render(request, 'recognition/login.html')

# Logout view
def logout_view(request):
    logout(request)
    return redirect('index')

# Upload image view
@login_required
def upload_image(request):
    if request.method == 'POST':
        form = UploadImageForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded = form.save(commit=False)
            uploaded.user = request.user
            uploaded.save()
            messages.success(request, "Image uploaded successfully!")
            return redirect('index')
    else:
        form = UploadImageForm()
    return render(request, 'recognition/upload.html', {'form': form})
